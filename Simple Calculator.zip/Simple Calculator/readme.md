# Simple Calculator

A beginner-friendly Python calculator that can:
- Add
- Subtract
- Multiply
- Divide (with zero-check)

# How to Run
```bash
python calculator.py
